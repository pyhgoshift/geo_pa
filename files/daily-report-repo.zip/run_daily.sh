#!/usr/bin/env bash
# 일일 보고서 원클릭 생성
# 사용법:  bash run_daily.sh <오늘응답.csv> [출력폴더]
set -e
CSV="${1:?사용법: bash run_daily.sh <응답CSV> [출력폴더] [보고일YYYY-MM-DD]}"
OUT="${2:-output}"
REPORT_DATE="${3:-}"
mkdir -p "$OUT"

echo "1) 데이터 분석 + index.html 생성"
python3 generate.py "$CSV" "$OUT" $REPORT_DATE

echo "2) PPT 생성"
( cd "$OUT" && node "$OLDPWD/build_ppt.js" report_data.json report.pptx )

# (선택) 파일 용량 최적화 — pptx 재압축 스크립트가 있으면 실행
if [ -f /mnt/skills/public/pptx/scripts/rezip.py ]; then
  python3 /mnt/skills/public/pptx/scripts/rezip.py "$OUT/report.pptx" >/dev/null 2>&1 || true
fi

echo ""
echo "완료 ✔  →  $OUT/index.html , $OUT/report.pptx"
echo "  · 웹 서비스용으로 쓰려면 index.html 을 그대로 웹서버에 올리면 됩니다."
