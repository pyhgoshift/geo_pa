#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
경기도교육청 정보자원 통합 만족도 조사 — 일일 보고서 자동 생성기 (승인 디자인 v1 고정)
사용법:  python3 generate.py <응답CSV경로> [출력폴더]
산출물:  <출력폴더>/index.html , <출력폴더>/report_data.json
형식·문구는 승인본과 동일하게 고정, CSV(같은 32열 구조)의 데이터만 매일 교체됩니다.
"""
import csv, json, sys, os, re, base64
from collections import Counter
from datetime import datetime, date as _date

# 로고(마크) 데이터 URI — generate.py와 같은 폴더의 assets/mark.png 자동 내장
_LOGO_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "mark.png")
try:
    with open(_LOGO_PATH, "rb") as _lf:
        LOGO_URI = "data:image/png;base64," + base64.b64encode(_lf.read()).decode()
except Exception:
    LOGO_URI = ""

CSV = sys.argv[1] if len(sys.argv) > 1 else "sample_responses.csv"
OUT = sys.argv[2] if len(sys.argv) > 2 else "."
# 선택: 보고일(집계일) 강제 지정 YYYY-MM-DD. 미지정 시 최신 응답일 사용.
REPORT_DATE = None
for a in sys.argv[3:]:
    m = re.match(r"(\d{4})-(\d{1,2})-(\d{1,2})", a)
    if m:
        REPORT_DATE = (int(m.group(1)), int(m.group(2)), int(m.group(3)))
os.makedirs(OUT, exist_ok=True)

with open(CSV, encoding="utf-8-sig") as f:
    rows = list(csv.reader(f))
header, data = rows[0], [r for r in rows[1:] if any(c.strip() for c in r)]
N = len(data)

def col(i):
    return [r[i].strip() if i < len(r) else "" for r in data]
def cnt(i):
    return Counter(v for v in col(i) if v)
def pct(n, d=N):
    return round(100*n/d, 1) if d else 0
def avg_num(idx_list):
    vals = [int(r[i]) for r in data for i in idx_list if i < len(r) and r[i].strip().isdigit()]
    return (round(sum(vals)/len(vals), 2), len(vals)) if vals else (0, 0)
def resp_count(idx_list):
    return sum(1 for r in data if any(i < len(r) and r[i].strip() for i in idx_list))

# ---------- 기간/집계일 ----------
def parse_ts(s):
    m = re.search(r"(\d{4})\.\s*(\d{1,2})\.\s*(\d{1,2})", s)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None
ts = [t for t in (parse_ts(r[0]) for r in data if r and r[0].strip()) if t]
if ts:
    first, last = min(ts), max(ts)
    period = f"{first[1]}.{first[2]}~{last[1]}.{last[2]}"
    rep = REPORT_DATE if REPORT_DATE else last          # 집계일 기준점
    agg_date = f"{rep[0]}. {rep[1]}. {rep[2]}."
    _wd = "월화수목금토일"[_date(*rep).weekday()]
    agg_date_full = f"{agg_date}({_wd})"
    days_span = (_date(*last) - _date(*first)).days + 1
    _dd = (_date(2026, 7, 1) - _date(*rep)).days
else:
    period, agg_date, days_span, _dd = "-", datetime.now().strftime("%Y. %-m. %-d."), 1, None
    agg_date_full = agg_date

# ---------- 응답자 구성 ----------
def items_of(i):
    return [(k, v, pct(v)) for k, v in cnt(i).most_common()]
inst_items, job_items, rank_items = items_of(1), items_of(2), items_of(3)

# ---------- 인지도 ----------
def yes_pct(counter):
    yes = counter.get("O", 0) or counter.get("예", 0) or counter.get("있음", 0)
    tot = sum(counter.values())
    return pct(yes, tot), yes, tot
know_proj_pct = yes_pct(cnt(8))
know_tr_pct   = yes_pct(cnt(9))

# ---------- 전반 만족도 (idx5) ----------
SAT_MAP = {"매우 만족":5,"만족":4,"보통":3,"불만족":2,"매우 불만족":1}
sat_counter = cnt(5)
sat_vals = [SAT_MAP[v] for v in col(5) if v in SAT_MAP]
overall_avg = round(sum(sat_vals)/len(sat_vals), 2) if sat_vals else 0
overall_n = len(sat_vals)
very = sat_counter.get("매우 만족", 0); satf = sat_counter.get("만족", 0)
dissat = sum(v for k, v in sat_counter.items() if k in ("불만족","매우 불만족"))

# ---------- 기대효과(idx10) + 우선순위(idx11~16) ----------
EFFECTS = [("보안 강화","보안강화",11),("업무 경감","업무경감",13),("장애 대응","장애대응",15),
           ("예산 절감","예산절감",14),("가용성 확보","가용성",12),("데이터기반행정","데이터기반행정",16)]
eff_raw = col(10)
eff_counts = {kw: sum(1 for cell in eff_raw if kw in cell) for _, kw, _ in EFFECTS}
prio = {kw: pct(cnt(idx).get("상", 0)) for _, kw, idx in EFFECTS}
CANON = ["보안강화","예산절감","장애대응","가용성","업무경감","데이터기반행정"]  # 동률 시 표시 순서(승인본 기준)
eff_sorted = sorted(EFFECTS, key=lambda x: -eff_counts[x[1]])
prio_sorted = sorted(EFFECTS, key=lambda x: (-prio[x[1]], CANON.index(x[1])))
top_effect = prio_sorted[0]

# ---------- 전환 만족도 ----------
TRN = avg_num([19,20,21]); TRN_n = resp_count([19,20,21])
MSA = avg_num([22,23,24,25,26]); MSA_n = resp_count([22,23,24,25,26])
CMS = avg_num([27,28,29,30,31]); CMS_n = resp_count([27,28,29,30,31])

# ---------- 자유의견 (idx17) ----------
NOISE = {"","없음","없습니다","없다",".","..","...","ㅇ","ㅇㅇ","-","무","감사","x","X"}
free = [t for t in (v.strip() for v in col(17)) if t and t not in NOISE and len(re.sub(r"[\s.·,]", "", t)) >= 3]
free_written = sum(1 for v in col(17) if v.strip())

# ===================== JSON =====================
D = {
  "N": N, "period": period, "agg_date": agg_date, "days_span": days_span, "dday": _dd,
  "inst": inst_items, "job": job_items, "rank": rank_items,
  "know_proj_pct": know_proj_pct[0], "know_tr_pct": know_tr_pct[0],
  "know_tr_yes": know_tr_pct[1], "know_tr_tot": know_tr_pct[2],
  "overall_avg": overall_avg, "overall_n": overall_n, "very": very, "satf": satf, "dissat": dissat,
  "eff_sorted": [(lbl, kw, eff_counts[kw]) for lbl, kw, _ in eff_sorted],
  "prio_sorted": [(lbl, kw, prio[kw]) for lbl, kw, _ in prio_sorted],
  "top_effect": (top_effect[0], prio[top_effect[1]]),
  "TRN": {"avg": TRN[0], "n": TRN_n}, "MSA": {"avg": MSA[0], "n": MSA_n}, "CMS": {"avg": CMS[0], "n": CMS_n},
  "free": free, "free_written": free_written,
}
with open(os.path.join(OUT, "report_data.json"), "w", encoding="utf-8") as f:
    json.dump(D, f, ensure_ascii=False, indent=2)

# ===================== HTML 헬퍼 =====================
def short(t):
    return re.sub(r"\s*\(.*$", "", t).strip()

def donut_svg(items):
    colors = ["#13294b", "#0aa6a0", "#e08a1e", "#6b7686", "#8aa0bf"]
    seg, cum = "", 0
    for i, (k, v, p) in enumerate(items):
        off = 25 - cum
        seg += (f'<circle cx="21" cy="21" r="15.9" fill="none" stroke="{colors[i%len(colors)]}" '
                f'stroke-width="7" stroke-dasharray="{p} {round(100-p,1)}" stroke-dashoffset="{round(off,1)}"/>')
        cum += p
    return seg

def legend_html(items):
    colors = ["#13294b", "#0aa6a0", "#e08a1e", "#6b7686", "#8aa0bf"]
    return "".join(f'<div><span class="dot" style="background:{colors[i%len(colors)]}"></span>{short(k)}'
                   f'<span class="lg-v">{v} · {p:.0f}%</span></div>' for i, (k, v, p) in enumerate(items))

def comp_rows(items):     # 직군/직급: 1위 막대에만 % 표기 (승인본 형식)
    out = ""
    for i, (k, v, p) in enumerate(items):
        inside = f"{p:.1f}%" if i == 0 else ""
        cls = "" if i == 0 else " navy"
        out += (f'<div class="row"><span class="lab">{short(k)}</span><div class="track">'
                f'<div class="fill{cls}" style="width:{p}%">{inside}</div></div><span class="val">{v}</span></div>')
    return out

def eff_rows():
    out = ""; vals = [v for _, _, v in D["eff_sorted"]]; mx = max(vals, default=1); lowv = min(vals, default=0)
    for lbl, kw, v in D["eff_sorted"]:
        w = max(3, round(100*v/mx))
        cls = "amber" if (v == lowv and v <= 2) else ("navy" if w < 55 else "")
        inside = str(v) if w > 12 else ""
        tail = "" if inside else f'<span class="val">{v}</span>'
        out += (f'<div class="row"><span class="lab">{lbl}</span><div class="track">'
                f'<div class="fill {cls}" style="width:{w}%">{inside}</div></div>{tail}</div>')
    return out

def prio_rows():
    out = ""; lowest = min(p for _, _, p in D["prio_sorted"])
    for lbl, kw, p in D["prio_sorted"]:
        cls = "amber" if p == lowest else ""
        out += (f'<div class="row"><span class="lab">{lbl}</span><div class="track">'
                f'<div class="fill {cls}" style="width:{p}%">{p:.1f}%</div></div></div>')
    return out

def free_cards():         # 자유의견 2열 (승인본 배치: 좌 amber·amber·plain / 우 plain·plain·teal-deep)
    qs = D["free"][:6]; left, right = qs[:3], qs[3:6]
    lcls = ["amber", "amber", ""]
    lhtml = "".join(f'<div class="q{(" "+c) if c else ""}">“{q}”</div>' for q, c in zip(left, lcls)) \
            or '<div class="q">유의미한 자유의견 없음</div>'
    rhtml = "".join(
        (f'<div class="q" style="border-left-color:#0a7d78">“{q}”</div>' if i == 2 else f'<div class="q">“{q}”</div>')
        for i, q in enumerate(right)) or '<div class="q">—</div>'
    return lhtml, rhtml

# ---- 파생 값 ----
te_label, te_pct = D["top_effect"]; te_nospace = te_label.replace(" ", "")
lo_prio = D["prio_sorted"][-1][0]
top_job = short(D["job"][0][0]); top_job_pct = D["job"][0][2]
sat_lo = round(min(D["TRN"]["avg"], D["MSA"]["avg"], D["CMS"]["avg"]), 1)
sat_hi = round(max(D["TRN"]["avg"], D["MSA"]["avg"], D["CMS"]["avg"]), 1)
small_lo, small_hi = min(D["MSA"]["n"], D["CMS"]["n"]), max(D["MSA"]["n"], D["CMS"]["n"])
if _dd is None: dday_txt = "전환 잔여 점검"
elif _dd > 0:   dday_txt = f"전환 D-{_dd} 잔여 점검"
elif _dd == 0:  dday_txt = "전환 D-Day(7/1) 점검"
else:           dday_txt = "전환 완료(7/1 경과) 점검"
def smeta(n):
    if n <= 5: return f'<span class="lowN">응답 {n}명 — 표본 극소</span> · 해석 주의'
    if n < 10: return f'<span class="lowN">응답 {n}명 — 표본 소수</span> · 참고치'
    return f'응답 {n}명'
trn_meta = f'응답 {D["TRN"]["n"]}명 · 운영/이전과정/안정화 3개 문항'
if D["dissat"] == 0:
    kpi_note = (f'※ 전반 만족도는 ‘통합 대상 시스템 관련자’ {D["overall_n"]}명 응답 기준이며, '
                f'<b>불만족 응답 0건(매우만족 {D["very"]} · 만족 {D["satf"]})</b>으로 만족 이상 100%.')
else:
    kpi_note = (f'※ 전반 만족도는 ‘통합 대상 시스템 관련자’ {D["overall_n"]}명 응답 기준 '
                f'(매우만족 {D["very"]} · 만족 {D["satf"]} · 불만족 {D["dissat"]}).')
lq, rq = free_cards()
TRN, MSA, CMS = D["TRN"], D["MSA"], D["CMS"]
logo_html = f'<div class="logo-card"><img src="{LOGO_URI}" alt="경기도교육청 · 아이티센 엔텍"></div>' if LOGO_URI else ""

# ===================== HTML =====================
HTML = f"""<!DOCTYPE html>
<html lang="ko"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>정보자원 통합 만족도 조사 · 일일 보고 ({D['agg_date']})</title>
<style>
  @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.css');
  :root{{--ink:#0d1b2a;--navy:#13294b;--navy-soft:#22406e;--paper:#eef1f6;--card:#fff;--line:#d9e0ec;
    --teal:#0aa6a0;--teal-deep:#0a7d78;--amber:#e08a1e;--amber-soft:#fbeccf;--muted:#6b7686;--grid:#eaeef4;--light:#eef1f6;}}
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Pretendard','Apple SD Gothic Neo','Malgun Gothic',sans-serif;background:var(--paper);color:var(--ink);line-height:1.5;-webkit-font-smoothing:antialiased;padding:28px 18px 60px}}
  .wrap{{max-width:1080px;margin:0 auto}}
  .head{{background:linear-gradient(135deg,var(--navy),#0c1c34);color:#fff;border-radius:18px;padding:30px 300px 30px 34px;position:relative;overflow:hidden;min-height:250px;box-shadow:0 18px 40px -18px rgba(13,27,42,.55)}}
  .head::after{{content:"";position:absolute;right:-60px;top:-60px;width:240px;height:240px;background:radial-gradient(circle,rgba(10,166,160,.35),transparent 65%)}}
  .eyebrow{{font-size:21px;letter-spacing:.02em;color:#cfe6ff;font-weight:800;display:flex;align-items:center;gap:10px}}
  .eyebrow::before{{content:"";width:6px;height:21px;border-radius:3px;background:linear-gradient(180deg,var(--teal),#3cc7c1)}}
  .head h1{{font-size:27px;font-weight:800;margin:11px 0 4px;letter-spacing:-.02em;line-height:1.25}}
  .head .sub{{margin-top:13px;display:inline-block;font-size:14.5px;color:#e3eefb;background:rgba(255,255,255,.09);border:1px solid rgba(255,255,255,.18);padding:9px 15px;border-radius:11px;line-height:1.55}}
  .head .sub b{{color:#fff;font-weight:800}}
  .head .sub .chip{{display:inline-block;vertical-align:middle;background:linear-gradient(135deg,var(--teal),var(--teal-deep));color:#fff;font-weight:800;padding:3px 11px;border-radius:7px;font-size:12.5px;letter-spacing:.01em;margin-right:9px}}
  .head-meta{{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px;position:relative;z-index:1}}
  .pill{{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);padding:6px 13px;border-radius:999px;font-size:12.5px}}
  .pill.warn{{background:rgba(224,138,30,.22);border-color:rgba(224,138,30,.5)}}
  .head-right{{position:absolute;top:26px;right:30px;width:250px;display:flex;flex-direction:column;gap:14px;z-index:2}}
  .logo-card{{background:#fff;border-radius:13px;padding:11px 15px;box-shadow:0 12px 26px -12px rgba(0,0,0,.5)}}
  .logo-card img{{display:block;width:100%;height:auto}}
  .dday{{text-align:right;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.16);border-radius:13px;padding:13px 17px}}
  .dday .big{{font-size:34px;font-weight:800;color:#fff;line-height:1}}
  .dday .lbl{{font-size:12px;color:#9fc7e8;margin-top:4px}}
  section{{margin-top:24px}}
  .s-title{{display:flex;align-items:center;gap:10px;margin:0 4px 12px}}
  .s-title .no{{font-size:12px;font-weight:800;color:#fff;background:var(--navy);width:24px;height:24px;border-radius:7px;display:grid;place-items:center}}
  .s-title h2{{font-size:16.5px;font-weight:700}}
  .s-title .tag{{margin-left:auto;font-size:11.5px;color:var(--muted)}}
  .grid{{display:grid;gap:16px}} .g4{{grid-template-columns:repeat(4,1fr)}} .g3{{grid-template-columns:repeat(3,1fr)}} .g2{{grid-template-columns:repeat(2,1fr)}}
  .card{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:20px}}
  .card h3{{font-size:13.5px;font-weight:700;color:var(--navy);margin-bottom:14px;display:flex;align-items:center;gap:7px}}
  .card h3 .n{{font-size:11px;color:var(--muted);font-weight:500;margin-left:auto}}
  .kpi{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px}}
  .kpi .v{{font-size:34px;font-weight:800;letter-spacing:-.03em;color:var(--navy);line-height:1}}
  .kpi .v small{{font-size:15px;font-weight:600;color:var(--muted)}}
  .kpi .k{{font-size:12.5px;color:var(--muted);margin-top:8px}}
  .kpi .bar{{height:4px;border-radius:4px;background:var(--grid);margin-top:12px;overflow:hidden}}
  .kpi .bar i{{display:block;height:100%;border-radius:4px;background:var(--teal)}}
  .kpi.accent .v{{color:var(--teal-deep)}}
  .row{{display:flex;align-items:center;gap:10px;margin:9px 0;font-size:13px}}
  .row .lab{{width:118px;flex:none;font-weight:500;font-size:12.5px}}
  .row .track{{flex:1;height:20px;background:var(--grid);border-radius:6px;overflow:hidden}}
  .row .fill{{height:100%;border-radius:6px;background:linear-gradient(90deg,var(--teal),#3cc7c1);display:flex;align-items:center;justify-content:flex-end;padding-right:8px;color:#fff;font-size:11px;font-weight:700;min-width:26px}}
  .row .fill.navy{{background:linear-gradient(90deg,var(--navy-soft),#37598f)}}
  .row .fill.amber{{background:linear-gradient(90deg,#d98318,#eba53f)}}
  .row .val{{width:54px;flex:none;text-align:right;color:var(--muted);font-weight:600}}
  .donut-wrap{{display:flex;align-items:center;gap:16px}}
  .legend{{font-size:12.5px;flex:1}} .legend div{{display:flex;align-items:center;gap:7px;margin:5px 0}}
  .legend .dot{{width:11px;height:11px;border-radius:3px;flex:none}} .legend .lg-v{{margin-left:auto;color:var(--muted);font-weight:600;padding-left:14px}}
  .sat{{display:flex;flex-direction:column;gap:4px;text-align:center;padding:6px 0}}
  .sat .score{{font-size:30px;font-weight:800;color:var(--teal-deep)}} .sat .score small{{font-size:14px;color:var(--muted);font-weight:600}}
  .sat .nm{{font-size:12.5px;font-weight:700;color:var(--navy)}} .sat .meta{{font-size:11px;color:var(--muted)}}
  .sat .stars{{margin:4px 0 2px;height:5px;border-radius:5px;background:var(--grid);overflow:hidden}} .sat .stars i{{display:block;height:100%;background:var(--teal)}}
  .lowN{{color:var(--amber);font-weight:600}}
  .quotes{{display:flex;flex-direction:column;gap:9px}}
  .q{{background:#f7f9fc;border-left:3px solid var(--teal);border-radius:0 8px 8px 0;padding:10px 13px;font-size:13px;color:#28323f}}
  .q.amber{{border-left-color:var(--amber)}}
  .persp{{border-radius:14px;padding:18px;border:1px solid var(--line);background:var(--card)}}
  .persp .ph{{font-size:13px;font-weight:800;display:flex;align-items:center;gap:8px;margin-bottom:10px}}
  .persp .badge{{font-size:10.5px;font-weight:700;color:#fff;padding:3px 9px;border-radius:6px}}
  .persp ul{{list-style:none;font-size:12.5px;color:#39424f}}
  .persp li{{padding:5px 0 5px 16px;position:relative;line-height:1.45}}
  .persp li::before{{content:"";position:absolute;left:0;top:11px;width:6px;height:6px;border-radius:2px;background:var(--teal)}}
  .persp.pm .badge{{background:var(--navy)}} .persp.tech .badge{{background:var(--teal-deep)}}
  .persp.biz .badge{{background:var(--amber)}} .persp.biz li::before{{background:var(--amber)}}
  .risk{{background:linear-gradient(180deg,#fffaf2,#fff);border:1px solid var(--amber-soft)}}
  .risk .ri{{display:flex;gap:12px;padding:11px 0;border-bottom:1px dashed var(--line)}} .risk .ri:last-child{{border-bottom:0}}
  .risk .ic{{flex:none;width:26px;height:26px;border-radius:8px;background:var(--amber-soft);color:var(--amber);display:grid;place-items:center;font-weight:800;font-size:13px}}
  .risk .rt{{font-size:13px}} .risk .rt b{{color:var(--navy)}} .risk .rt span{{color:var(--muted);display:block;margin-top:2px;font-size:12px}}
  .note{{font-size:11.5px;color:var(--muted);margin-top:8px;padding-left:4px;line-height:1.5}}
  footer{{margin-top:30px;text-align:center;font-size:11.5px;color:var(--muted);border-top:1px solid var(--line);padding-top:16px}}
  @media(max-width:820px){{.g4{{grid-template-columns:repeat(2,1fr)}} .g3,.g2{{grid-template-columns:1fr}}
    .head{{padding:26px 20px;min-height:0}} .head-right{{position:static;width:auto;margin-top:18px;flex-direction:row;align-items:stretch}}
    .logo-card{{flex:1}} .dday{{flex:1;display:flex;flex-direction:column;justify-content:center;text-align:left}} .row .lab{{width:88px}}}}
</style></head><body><div class="wrap">

  <header class="head">
    <div class="eyebrow">경기도교육청</div>
    <h1>정보자원 통합 성과 및 시스템 이전·통합 만족도 조사</h1>
    <div class="sub"><span class="chip">설문 응답 현황 · 일일 리포트</span> 집계일 <b>{agg_date_full} 09:00</b> 기준 · 응답기간 <b>{D['period']}</b></div>
    <div class="head-meta">
      <span class="pill">누적 응답 <b>{D['N']}건</b></span>
      <span class="pill">사업 인지도 <b>{D['know_proj_pct']:.0f}%</b></span>
      <span class="pill">전반 만족도 <b>{D['overall_avg']} / 5.0</b></span>
      <span class="pill warn">최우선 기대 · {te_nospace} <b>{te_pct:.1f}%</b></span>
    </div>
    <div class="head-right">
      {logo_html}
      <div class="dday"><div class="big">{D['overall_avg']}<span style="font-size:18px;color:#9fc7e8;font-weight:600">/5</span></div>
        <div class="lbl">추진과정 전반 만족도</div></div>
    </div>
  </header>

  <!-- 1. KPI -->
  <section>
    <div class="s-title"><span class="no">1</span><h2>핵심 지표 요약</h2><span class="tag">전일 대비 누적 집계</span></div>
    <div class="grid g4">
      <div class="kpi accent"><div class="v">{D['N']}<small>건</small></div><div class="k">누적 응답 수 ({D['days_span']}일간)</div><div class="bar"><i style="width:{min(100,D['N'])}%"></i></div></div>
      <div class="kpi"><div class="v">{D['know_proj_pct']:.0f}<small>%</small></div><div class="k">통합 사업 인지율 ({D['N']}/{D['N']})</div><div class="bar"><i style="width:{D['know_proj_pct']}%"></i></div></div>
      <div class="kpi accent"><div class="v">{D['overall_avg']}<small>/5</small></div><div class="k">추진과정 전반 만족도 (n={D['overall_n']})</div><div class="bar"><i style="width:{D['overall_avg']*20}%"></i></div></div>
      <div class="kpi"><div class="v">{D['know_tr_pct']:.1f}<small>%</small></div><div class="k">7/1 전담관리 전환 인지 ({D['know_tr_yes']}/{D['know_tr_tot']})</div><div class="bar"><i style="width:{D['know_tr_pct']}%"></i></div></div>
    </div>
    <div class="note">{kpi_note}</div>
  </section>

  <!-- 2. 응답자 구성 -->
  <section>
    <div class="s-title"><span class="no">2</span><h2>응답자 구성</h2><span class="tag">표본 대표성 점검 포함</span></div>
    <div class="grid g3">
      <div class="card"><h3>기관 유형 <span class="n">n={D['N']}</span></h3>
        <div class="donut-wrap"><svg width="118" height="118" viewBox="0 0 42 42" aria-label="기관유형 도넛">
          <circle cx="21" cy="21" r="15.9" fill="none" stroke="#eaeef4" stroke-width="7"/>{donut_svg(D['inst'])}
          <text x="21" y="20.5" text-anchor="middle" font-size="6" font-weight="800" fill="#13294b">{D['N']}</text>
          <text x="21" y="25.5" text-anchor="middle" font-size="3" fill="#6b7686">응답</text></svg>
          <div class="legend" style="flex:1">{legend_html(D['inst'])}</div></div></div>
      <div class="card"><h3>직군 <span class="n">n={D['N']}</span></h3>{comp_rows(D['job'])}
        <div class="note" style="margin-top:12px">응답자 <b>대다수가 {top_job}직(공급·운영 측)</b> — 일반 현업 사용자 시각은 제한적.</div></div>
      <div class="card"><h3>직급 <span class="n">n={D['N']}</span></h3>{comp_rows(D['rank'])}
        <div class="note" style="margin-top:12px">실무 담당자 중심 표본. <b>관리자급 의사결정 시각</b>은 별도 확인 필요.</div></div>
    </div>
  </section>

  <!-- 3. 전환·통합 만족도 -->
  <section>
    <div class="s-title"><span class="no">3</span><h2>전환·통합 만족도</h2><span class="tag">5점 척도 / 영역별</span></div>
    <div class="grid g3">
      <div class="card"><div class="sat"><div class="nm">TRN · 이전 통합</div><div class="score">{TRN['avg']:.2f}<small>/5</small></div>
        <div class="stars"><i style="width:{TRN['avg']*20}%"></i></div><div class="meta">{trn_meta}</div></div></div>
      <div class="card"><div class="sat"><div class="nm">MSA · 신규 개발</div><div class="score">{MSA['avg']:.2f}<small>/5</small></div>
        <div class="stars"><i style="width:{MSA['avg']*20}%"></i></div><div class="meta">{smeta(MSA['n'])}</div></div></div>
      <div class="card"><div class="sat"><div class="nm">CMS · 홈페이지 전환</div><div class="score">{CMS['avg']:.2f}<small>/5</small></div>
        <div class="stars"><i style="width:{CMS['avg']*20}%"></i></div><div class="meta">{smeta(CMS['n'])}</div></div></div>
    </div>
    <div class="note">※ 세 영역 모두 4점대 후반으로 높으나, MSA·CMS는 해당 대상기관 담당자({small_lo}~{small_hi}명)만 응답 → <b>만점에 가까운 수치를 ‘전체 성과’로 일반화하지 않도록 주의.</b></div>
  </section>

  <!-- 4. 기대효과 -->
  <section>
    <div class="s-title"><span class="no">4</span><h2>통합 기대효과 · 우선순위</h2><span class="tag">II-6 다중선택 / 우선순위 ‘상’ 비율</span></div>
    <div class="grid g2">
      <div class="card"><h3>가장 기대되는 효과 (TOP3 선택) <span class="n">복수응답</span></h3>{eff_rows()}</div>
      <div class="card"><h3>항목별 우선순위 ‘상’ 응답 비율 <span class="n">n={D['N']}</span></h3>{prio_rows()}</div>
    </div>
    <div class="note">※ <b>‘{lo_prio}’이 두 지표 모두 최하위</b> — 현장은 통합을 보안·비용·운영부담 관점으로 체감하며, 통합의 미래지향 가치(데이터 행정)에 대한 기대·인식은 상대적으로 낮음.</div>
  </section>

  <!-- 5. 자유의견 -->
  <section>
    <div class="s-title"><span class="no">5</span><h2>현장 자유의견 (핵심 신호)</h2><span class="tag">작성 {D['free_written']}/{D['N']} · 실질 의견 발췌</span></div>
    <div class="grid g2">
      <div class="quotes">{lq}</div>
      <div class="quotes">{rq}</div>
    </div>
    <div class="note">※ 형식적 응답(‘없음’·‘.’ 등)을 제외하면 실질 의견은 소수지만, 방향은 일관됨 — <b>인프라 통합은 됐고, 이제 운영체계(ITSM)·응용 통합·거버넌스가 다음 과제</b>라는 현장 메시지.</div>
  </section>

  <!-- 6. 3대 관점 -->
  <section>
    <div class="s-title"><span class="no">6</span><h2>관점별 종합 진단</h2><span class="tag">사업관리 · 기술 · 비즈니스</span></div>
    <div class="grid g3">
      <div class="persp pm">
        <div class="ph"><span class="badge">사업관리</span> 추진·일정·참여</div>
        <ul>
          <li>인지도 {D['know_proj_pct']:.0f}%, 7/1 전환 인지 {D['know_tr_pct']:.1f}% — <b>전환 직전 준비도 양호</b></li>
          <li>전반 만족 {D['overall_avg']}, 불만 {D['dissat']}건 — 추진 성과 자체는 긍정</li>
          <li>리스크: 응답 {D['N']}건으로 표본 작음 / 미참여층 응답 확보 점검</li>
        </ul>
      </div>
      <div class="persp tech">
        <div class="ph"><span class="badge">기술</span> 성능·안정화</div>
        <ul>
          <li>TRN·MSA·CMS 전환 후 만족 {sat_lo}~{sat_hi} — <b>안정화 성공적</b></li>
          <li>예약 등 트래픽 집중 업무 무중단 운영 확인(MSA)</li>
          <li>과제: <b>응용 유지관리·ITSM·통합관제</b> 등 운영 성숙도</li>
        </ul>
      </div>
      <div class="persp biz">
        <div class="ph"><span class="badge">비즈니스</span> 가치·업무효과</div>
        <ul>
          <li>보안·예산·업무경감 기대 高 → <b>운영 효율 기대 뚜렷</b></li>
          <li>{lo_prio} 가치 체감 低 → 미래 비전 공감 부족</li>
          <li>현업(비전산) 사용자 목소리 부족 → 효과 검증 한계</li>
        </ul>
      </div>
    </div>
  </section>

  <!-- 7. 리스크 -->
  <section>
    <div class="s-title"><span class="no">7</span><h2>결론 재점검 · 리스크 &amp; 빠진 부분</h2><span class="tag">수치 과잉해석 경계</span></div>
    <div class="card risk">
      <div class="ri"><div class="ic">!</div><div class="rt"><b>‘만족도 100%’는 액면 그대로 읽지 말 것</b>
        <span>응답자의 {top_job_pct:.1f}%가 {top_job}직, 전반만족 평가자도 사업 관련자 {D['overall_n']}명. 사실상 ‘추진·운영 주체에 가까운 집단’의 자기평가 → 긍정 편향 가능. 현업 일반 사용자 체감과 구분 필요.</span></div></div>
      <div class="ri"><div class="ic">N</div><div class="rt"><b>MSA({MSA['n']}명)·CMS({CMS['n']}명) 표본 극소</b>
        <span>만점에 가까운 점수지만 통계적 일반화 불가. 보고 시 ‘대상기관 담당자 한정 참고치’로 명시.</span></div></div>
      <div class="ri"><div class="ic">▽</div><div class="rt"><b>{lo_prio} 가치, 현장 공감 최저</b>
        <span>통합의 장기 명분(데이터 연계 행정)이 체감되지 않음. 전환 후 비전·활용 사례 커뮤니케이션 보강 필요.</span></div></div>
      <div class="ri"><div class="ic">↻</div><div class="rt"><b>다음 과제는 ‘인프라’가 아니라 ‘운영·응용·거버넌스’</b>
        <span>자유의견이 ITSM·응용 통합·전담 조율조직·협력강화로 수렴. 7/1 전담관리 개시 후 운영 SLA·협업체계가 실제 만족을 좌우할 변수.</span></div></div>
      <div class="ri"><div class="ic">?</div><div class="rt"><b>빠진 데이터</b>
        <span>① 모집단 대비 응답률(분모) 미상 → {D['N']}건의 대표성 판단 불가 ② 부정·중립 응답이 적어 ‘무응답·미참여층’의 잠재 불만 미파악 ③ 응답률 일자별 추이(전일 대비)는 향후 자동 집계 권장.</span></div></div>
    </div>
  </section>

  <footer>
    경기도교육청 교육정보기록원 · 정보자원 통합 만족도 조사 일일 보고 · 데이터 기준 {D['agg_date']} 09:00 (응답 {D['N']}건)<br>
    본 리포트의 만족도·표본 수치는 설문 원자료 기반 자동 집계이며, 소수 표본 항목은 참고치로 해석.
  </footer>
</div></body></html>"""

with open(os.path.join(OUT, "index.html"), "w", encoding="utf-8") as f:
    f.write(HTML)
print(f"[OK] 응답 {N}건 · 집계일 {agg_date} · index.html + report_data.json 생성 완료 → {OUT}")
