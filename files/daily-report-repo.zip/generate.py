#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
경기도교육청 정보자원 통합 만족도 조사 — 일일 보고서 자동 생성기
사용법:  python3 generate.py <응답CSV경로> [출력폴더]
산출물:  <출력폴더>/index.html , <출력폴더>/report_data.json
형식은 고정, CSV(같은 32열 구조)의 데이터만 매일 교체됩니다.
"""
import csv, json, sys, os, re
from collections import Counter
from datetime import datetime

CSV = sys.argv[1] if len(sys.argv) > 1 else "sample_responses.csv"
OUT = sys.argv[2] if len(sys.argv) > 2 else "."
os.makedirs(OUT, exist_ok=True)

with open(CSV, encoding="utf-8-sig") as f:
    rows = list(csv.reader(f))
header, data = rows[0], [r for r in rows[1:] if any(c.strip() for c in r)]
N = len(data)

def col(i):           # 안전한 컬럼 접근
    return [r[i].strip() if i < len(r) else "" for r in data]
def cnt(i):
    return Counter(v for v in col(i) if v)
def pct(n, d=N):
    return round(100*n/d, 1) if d else 0
def avg_num(idx_list):
    vals = [int(r[i]) for r in data for i in idx_list if i < len(r) and r[i].strip().isdigit()]
    return (round(sum(vals)/len(vals), 2), len(vals)) if vals else (0, 0)
def resp_count(idx_list):   # 해당 영역에 하나라도 응답한 사람 수
    s = 0
    for r in data:
        if any(i < len(r) and r[i].strip() for i in idx_list):
            s += 1
    return s

# ---------- 1. 기간/집계일 ----------
def parse_ts(s):
    m = re.search(r"(\d{4})\.\s*(\d{1,2})\.\s*(\d{1,2})", s)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None
ts = [parse_ts(r[0]) for r in data if r and r[0].strip()]
ts = [t for t in ts if t]
if ts:
    first, last = min(ts), max(ts)
    period = f"{first[1]}.{first[2]}~{last[1]}.{last[2]}"
    agg_date = f"{last[0]}. {last[1]}. {last[2]}."
else:
    period, agg_date = "-", datetime.now().strftime("%Y. %-m. %-d.")

# ---------- 2. 응답자 구성 ----------
inst = cnt(1)   # 기관유형
job  = cnt(2)   # 직군
rank = cnt(3)   # 직급
def top3(counter, keys=None):
    items = counter.most_common()
    return [(k, v, pct(v)) for k, v in items]
inst_items = top3(inst)
job_items  = top3(job)
rank_items = top3(rank)

# ---------- 3. 인지도 ----------
know_proj = cnt(8)  # II-4
know_tr   = cnt(9)  # II-5
def yes_pct(counter):
    yes = counter.get("O", 0) or counter.get("예", 0) or counter.get("있음", 0)
    tot = sum(counter.values())
    return pct(yes, tot), yes, tot
know_proj_pct = yes_pct(know_proj)
know_tr_pct   = yes_pct(know_tr)

# ---------- 4. 전반 만족도 (II-1-1, idx 5) ----------
SAT_MAP = {"매우 만족":5,"만족":4,"보통":3,"불만족":2,"매우 불만족":1}
sat_counter = cnt(5)
sat_vals = [SAT_MAP[v] for v in col(5) if v in SAT_MAP]
overall_avg = round(sum(sat_vals)/len(sat_vals), 2) if sat_vals else 0
overall_n   = len(sat_vals)
very = sat_counter.get("매우 만족", 0); satf = sat_counter.get("만족", 0)
dissat = sum(v for k, v in sat_counter.items() if k in ("불만족","매우 불만족"))

# ---------- 5. 기대효과(다중,idx10) + 우선순위 상(idx11~16) ----------
EFFECTS = [("보안 강화","보안강화",11),("업무 경감","업무경감",13),("장애 대응","장애대응",15),
           ("예산 절감","예산절감",14),("가용성 확보","가용성",12),("데이터기반행정","데이터기반행정",16)]
# 다중선택 집계: 옵션 텍스트에 콤마가 있어 키워드 매칭으로 카운트
eff_raw = col(10)
def eff_count(keyword):
    return sum(1 for cell in eff_raw if keyword in cell)
eff_counts = {kw: eff_count(kw) for _, kw, _ in EFFECTS}
# 우선순위 '상' 비율
prio = {}
for label, kw, idx in EFFECTS:
    c = cnt(idx)
    sang = c.get("상", 0)
    prio[kw] = pct(sang)
# 정렬: 기대효과는 선택수 내림차순
eff_sorted = sorted(EFFECTS, key=lambda x: -eff_counts[x[1]])
prio_sorted = sorted(EFFECTS, key=lambda x: -prio[x[1]])
top_effect = prio_sorted[0]            # 헤더 pill용 (최우선)

# ---------- 6. 전환 만족도 TRN/MSA/CMS ----------
TRN = avg_num([19,20,21]); TRN_n = resp_count([19,20,21])
MSA = avg_num([22,23,24,25,26]); MSA_n = resp_count([22,23,24,25,26])
CMS = avg_num([27,28,29,30,31]); CMS_n = resp_count([27,28,29,30,31])

# ---------- 7. 자유의견 (idx17) ----------
NOISE = {"","없음","없습니다","없다",".","..","...","ㅇ","ㅇㅇ","-","무","감사","x","X"}
free = []
for v in col(17):
    t = v.strip()
    if t and t not in NOISE and len(re.sub(r"[\s.·,]", "", t)) >= 3:
        free.append(t)
free_written = sum(1 for v in col(17) if v.strip())

# ===================== JSON =====================
D = {
  "N": N, "period": period, "agg_date": agg_date,
  "inst": inst_items, "job": job_items, "rank": rank_items,
  "know_proj_pct": know_proj_pct[0], "know_tr_pct": know_tr_pct[0],
  "know_tr_yes": know_tr_pct[1], "know_tr_tot": know_tr_pct[2],
  "overall_avg": overall_avg, "overall_n": overall_n,
  "very": very, "satf": satf, "dissat": dissat,
  "effects": [(lbl, kw, eff_counts[kw]) for lbl, kw, _ in EFFECTS],
  "eff_sorted": [(lbl, kw, eff_counts[kw]) for lbl, kw, _ in eff_sorted],
  "prio_sorted": [(lbl, kw, prio[kw]) for lbl, kw, _ in prio_sorted],
  "top_effect": (top_effect[0], prio[top_effect[1]]),
  "TRN": {"avg": TRN[0], "n": TRN_n}, "MSA": {"avg": MSA[0], "n": MSA_n},
  "CMS": {"avg": CMS[0], "n": CMS_n},
  "free": free, "free_written": free_written,
}
with open(os.path.join(OUT, "report_data.json"), "w", encoding="utf-8") as f:
    json.dump(D, f, ensure_ascii=False, indent=2)

# ===================== HTML =====================
def donut_svg(items):
    colors = ["#13294b", "#0aa6a0", "#e08a1e", "#6b7686", "#8aa0bf"]
    seg = ""; cum = 0
    for i, (k, v, p) in enumerate(items):
        off = 25 - cum
        seg += (f'<circle cx="21" cy="21" r="15.9" fill="none" stroke="{colors[i%len(colors)]}" '
                f'stroke-width="7" stroke-dasharray="{p} {round(100-p,1)}" stroke-dashoffset="{round(off,1)}"/>')
        cum += p
    return seg

def legend_html(items):
    colors = ["#13294b", "#0aa6a0", "#e08a1e", "#6b7686", "#8aa0bf"]
    out = ""
    for i, (k, v, p) in enumerate(items):
        out += (f'<div><span class="dot" style="background:{colors[i%len(colors)]}"></span>{k}'
                f'<span class="lg-v">{v} · {p:.0f}%</span></div>')
    return out

def job_rows():
    out = ""
    mx = max((v for _, v, _ in D["job"]), default=1)
    for k, v, p in D["job"]:
        out += (f'<div class="row"><span class="lab">{k}</span><div class="track">'
                f'<div class="fill{" navy" if p<50 else ""}" style="width:{p}%">{p:.1f}%</div></div>'
                f'<span class="val">{v}</span></div>')
    return out
def rank_rows():
    out = ""
    for k, v, p in D["rank"]:
        out += (f'<div class="row"><span class="lab">{k}</span><div class="track">'
                f'<div class="fill{" navy" if p<50 else ""}" style="width:{p}%">{p:.1f}%</div></div>'
                f'<span class="val">{v}</span></div>')
    return out
def eff_rows():
    out = ""; mx = max((v for _, _, v in D["eff_sorted"]), default=1)
    for lbl, kw, v in D["eff_sorted"]:
        w = max(3, round(100*v/mx))
        cls = "amber" if v == min(x[2] for x in D["eff_sorted"]) and v<=2 else ("navy" if w<55 else "")
        inside = str(v) if w > 12 else ""
        tail = f'<span class="val">{v}</span>' if not inside else ""
        out += (f'<div class="row"><span class="lab">{lbl}</span><div class="track">'
                f'<div class="fill {cls}" style="width:{w}%">{inside}</div></div>{tail}</div>')
    return out
def prio_rows():
    out = ""; lowest = min(p for _,_,p in D["prio_sorted"])
    for lbl, kw, p in D["prio_sorted"]:
        cls = "amber" if p == lowest else ""
        out += (f'<div class="row"><span class="lab">{lbl}</span><div class="track">'
                f'<div class="fill {cls}" style="width:{p}%">{p:.1f}%</div></div></div>')
    return out
def quotes_html():
    cols = [[], []]
    for i, q in enumerate(D["free"][:8]):
        cols[i % 2].append(q)
    def block(lst):
        return "".join(f'<div class="q">{q}</div>' for q in lst) or '<div class="q">유의미한 자유의견 없음</div>'
    return block(cols[0]), block(cols[1])

q1, q2 = quotes_html()
TRN, MSA, CMS = D["TRN"], D["MSA"], D["CMS"]
te_label, te_pct = D["top_effect"]

HTML = f"""<!DOCTYPE html>
<html lang="ko"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>정보자원 통합 만족도 조사 · 일일 보고 ({D['agg_date']})</title>
<style>
  @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.css');
  :root{{--ink:#0d1b2a;--navy:#13294b;--navy-soft:#22406e;--paper:#eef1f6;--card:#fff;--line:#d9e0ec;
    --teal:#0aa6a0;--teal-deep:#0a7d78;--amber:#e08a1e;--amber-soft:#fbeccf;--muted:#6b7686;--grid:#eaeef4;--light:#eef1f6;}}
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Pretendard','Apple SD Gothic Neo','Malgun Gothic',sans-serif;background:var(--paper);color:var(--ink);line-height:1.5;-webkit-font-smoothing:antialiased;padding:28px 18px 60px}}
  .wrap{{max-width:1080px;margin:0 auto}}
  .head{{background:linear-gradient(135deg,var(--navy),#0c1c34);color:#fff;border-radius:18px;padding:30px 34px;position:relative;overflow:hidden;box-shadow:0 18px 40px -18px rgba(13,27,42,.55)}}
  .head::after{{content:"";position:absolute;right:-60px;top:-60px;width:240px;height:240px;background:radial-gradient(circle,rgba(10,166,160,.35),transparent 65%)}}
  .eyebrow{{font-size:12.5px;letter-spacing:.18em;color:#9fc7e8;font-weight:600}}
  .head h1{{font-size:27px;font-weight:800;margin:8px 0 4px;letter-spacing:-.02em;line-height:1.25}}
  .head .sub{{color:#c4d4e6;font-size:14px}}
  .head-meta{{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;position:relative;z-index:1}}
  .pill{{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);padding:6px 13px;border-radius:999px;font-size:12.5px}}
  .pill.warn{{background:rgba(224,138,30,.22);border-color:rgba(224,138,30,.5)}}
  .dday{{position:absolute;right:30px;bottom:26px;text-align:right;z-index:1}}
  .dday .big{{font-size:34px;font-weight:800;color:#fff;line-height:1}}
  .dday .lbl{{font-size:11.5px;color:#9fc7e8;margin-top:3px}}
  section{{margin-top:24px}}
  .s-title{{display:flex;align-items:center;gap:10px;margin:0 4px 12px}}
  .s-title .no{{font-size:12px;font-weight:800;color:#fff;background:var(--navy);width:24px;height:24px;border-radius:7px;display:grid;place-items:center}}
  .s-title h2{{font-size:16.5px;font-weight:700}}
  .s-title .tag{{margin-left:auto;font-size:11.5px;color:var(--muted)}}
  .grid{{display:grid;gap:16px}} .g4{{grid-template-columns:repeat(4,1fr)}} .g3{{grid-template-columns:repeat(3,1fr)}} .g2{{grid-template-columns:repeat(2,1fr)}}
  .card{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:20px}}
  .card h3{{font-size:13.5px;font-weight:700;color:var(--navy);margin-bottom:14px;display:flex;align-items:center;gap:7px}}
  .card h3 .n{{font-size:11px;color:var(--muted);font-weight:500;margin-left:auto}}
  .kpi{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px}}
  .kpi .v{{font-size:34px;font-weight:800;letter-spacing:-.03em;color:var(--navy);line-height:1}}
  .kpi .v small{{font-size:15px;font-weight:600;color:var(--muted)}}
  .kpi .k{{font-size:12.5px;color:var(--muted);margin-top:8px}}
  .kpi .bar{{height:4px;border-radius:4px;background:var(--grid);margin-top:12px;overflow:hidden}}
  .kpi .bar i{{display:block;height:100%;border-radius:4px;background:var(--teal)}}
  .kpi.accent .v{{color:var(--teal-deep)}}
  .row{{display:flex;align-items:center;gap:10px;margin:9px 0;font-size:13px}}
  .row .lab{{width:118px;flex:none;font-weight:500;font-size:12.5px}}
  .row .track{{flex:1;height:20px;background:var(--grid);border-radius:6px;overflow:hidden}}
  .row .fill{{height:100%;border-radius:6px;background:linear-gradient(90deg,var(--teal),#3cc7c1);display:flex;align-items:center;justify-content:flex-end;padding-right:8px;color:#fff;font-size:11px;font-weight:700;min-width:26px}}
  .row .fill.navy{{background:linear-gradient(90deg,var(--navy-soft),#37598f)}}
  .row .fill.amber{{background:linear-gradient(90deg,#d98318,#eba53f)}}
  .row .val{{width:54px;flex:none;text-align:right;color:var(--muted);font-weight:600}}
  .donut-wrap{{display:flex;align-items:center;gap:16px}}
  .legend{{font-size:12.5px;flex:1}} .legend div{{display:flex;align-items:center;gap:7px;margin:5px 0}}
  .legend .dot{{width:11px;height:11px;border-radius:3px;flex:none}} .legend .lg-v{{margin-left:auto;color:var(--muted);font-weight:600;padding-left:14px}}
  .sat{{display:flex;flex-direction:column;gap:4px;text-align:center;padding:6px 0}}
  .sat .score{{font-size:30px;font-weight:800;color:var(--teal-deep)}} .sat .score small{{font-size:14px;color:var(--muted);font-weight:600}}
  .sat .nm{{font-size:12.5px;font-weight:700;color:var(--navy)}} .sat .meta{{font-size:11px;color:var(--muted)}}
  .sat .stars{{margin:4px 0 2px;height:5px;border-radius:5px;background:var(--grid);overflow:hidden}} .sat .stars i{{display:block;height:100%;background:var(--teal)}}
  .lowN{{color:var(--amber);font-weight:600}}
  .quotes{{display:flex;flex-direction:column;gap:9px}}
  .q{{background:#f7f9fc;border-left:3px solid var(--teal);border-radius:0 8px 8px 0;padding:10px 13px;font-size:13px;color:#28323f}}
  .persp{{border-radius:14px;padding:18px;border:1px solid var(--line);background:var(--card)}}
  .persp .ph{{font-size:13px;font-weight:800;display:flex;align-items:center;gap:8px;margin-bottom:10px}}
  .persp .badge{{font-size:10.5px;font-weight:700;color:#fff;padding:3px 9px;border-radius:6px}}
  .persp ul{{list-style:none;font-size:12.5px;color:#39424f}}
  .persp li{{padding:5px 0 5px 16px;position:relative;line-height:1.45}}
  .persp li::before{{content:"";position:absolute;left:0;top:11px;width:6px;height:6px;border-radius:2px;background:var(--teal)}}
  .persp.pm .badge{{background:var(--navy)}} .persp.tech .badge{{background:var(--teal-deep)}}
  .persp.biz .badge{{background:var(--amber)}} .persp.biz li::before{{background:var(--amber)}}
  .risk{{background:linear-gradient(180deg,#fffaf2,#fff);border:1px solid var(--amber-soft)}}
  .risk .ri{{display:flex;gap:12px;padding:11px 0;border-bottom:1px dashed var(--line)}} .risk .ri:last-child{{border-bottom:0}}
  .risk .ic{{flex:none;width:26px;height:26px;border-radius:8px;background:var(--amber-soft);color:var(--amber);display:grid;place-items:center;font-weight:800;font-size:13px}}
  .risk .rt{{font-size:13px}} .risk .rt b{{color:var(--navy)}} .risk .rt span{{color:var(--muted);display:block;margin-top:2px;font-size:12px}}
  .note{{font-size:11.5px;color:var(--muted);margin-top:8px;padding-left:4px;line-height:1.5}}
  footer{{margin-top:30px;text-align:center;font-size:11.5px;color:var(--muted);border-top:1px solid var(--line);padding-top:16px}}
  @media(max-width:820px){{.g4{{grid-template-columns:repeat(2,1fr)}} .g3,.g2{{grid-template-columns:1fr}} .dday{{position:static;text-align:left;margin-top:14px}} .row .lab{{width:88px}}}}
</style></head><body><div class="wrap">

  <header class="head">
    <div class="eyebrow">경기도교육청</div>
    <h1>정보자원 통합 성과 및 시스템 이전·통합 만족도 조사</h1>
    <div class="sub">설문 응답 현황 일일 리포트 · 집계일 {D['agg_date']} 09:00 기준 · 응답기간 {D['period']}</div>
    <div class="head-meta">
      <span class="pill">누적 응답 <b>{D['N']}건</b></span>
      <span class="pill">사업 인지도 <b>{D['know_proj_pct']:.0f}%</b></span>
      <span class="pill">전반 만족도 <b>{D['overall_avg']} / 5.0</b></span>
      <span class="pill warn">최우선 기대 · {te_label} <b>{te_pct:.1f}%</b></span>
    </div>
    <div class="dday"><div class="big">{D['overall_avg']}<span style="font-size:18px;color:#9fc7e8;font-weight:600">/5</span></div>
      <div class="lbl">추진과정 전반 만족도</div></div>
  </header>

  <section>
    <div class="s-title"><span class="no">1</span><h2>핵심 지표 요약</h2><span class="tag">누적 집계</span></div>
    <div class="grid g4">
      <div class="kpi accent"><div class="v">{D['N']}<small>건</small></div><div class="k">누적 응답 수</div><div class="bar"><i style="width:{min(100,D['N'])}%"></i></div></div>
      <div class="kpi"><div class="v">{D['know_proj_pct']:.0f}<small>%</small></div><div class="k">통합 사업 인지율</div><div class="bar"><i style="width:{D['know_proj_pct']}%"></i></div></div>
      <div class="kpi accent"><div class="v">{D['overall_avg']}<small>/5</small></div><div class="k">추진과정 전반 만족도 (n={D['overall_n']})</div><div class="bar"><i style="width:{D['overall_avg']*20}%"></i></div></div>
      <div class="kpi"><div class="v">{D['know_tr_pct']:.1f}<small>%</small></div><div class="k">전담관리 전환 인지 ({D['know_tr_yes']}/{D['know_tr_tot']})</div><div class="bar"><i style="width:{D['know_tr_pct']}%"></i></div></div>
    </div>
    <div class="note">※ 전반 만족도는 ‘통합 대상 시스템 관련자’ {D['overall_n']}명 응답 기준 (매우만족 {D['very']} · 만족 {D['satf']} · 불만족 {D['dissat']}).</div>
  </section>

  <section>
    <div class="s-title"><span class="no">2</span><h2>응답자 구성</h2><span class="tag">표본 대표성 점검 포함</span></div>
    <div class="grid g3">
      <div class="card"><h3>기관 유형 <span class="n">n={D['N']}</span></h3>
        <div class="donut-wrap"><svg width="118" height="118" viewBox="0 0 42 42">
          <circle cx="21" cy="21" r="15.9" fill="none" stroke="#eaeef4" stroke-width="7"/>{donut_svg(D['inst'])}
          <text x="21" y="20.5" text-anchor="middle" font-size="6" font-weight="800" fill="#13294b">{D['N']}</text>
          <text x="21" y="25.5" text-anchor="middle" font-size="3" fill="#6b7686">응답</text></svg>
          <div class="legend">{legend_html(D['inst'])}</div></div></div>
      <div class="card"><h3>직군 <span class="n">n={D['N']}</span></h3>{job_rows()}
        <div class="note" style="margin-top:12px">응답자 직군 구성 — <b>{D['job'][0][0]}</b>가 {D['job'][0][2]:.1f}%로 다수.</div></div>
      <div class="card"><h3>직급 <span class="n">n={D['N']}</span></h3>{rank_rows()}
        <div class="note" style="margin-top:12px">실무 담당자 중심 표본. <b>관리자급 의사결정 시각</b>은 별도 확인 권장.</div></div>
    </div>
  </section>

  <section>
    <div class="s-title"><span class="no">3</span><h2>전환·통합 만족도</h2><span class="tag">5점 척도 / 영역별</span></div>
    <div class="grid g3">
      <div class="card"><div class="sat"><div class="nm">TRN · 이전 통합</div><div class="score">{TRN['avg']}<small>/5</small></div>
        <div class="stars"><i style="width:{TRN['avg']*20}%"></i></div><div class="meta">응답 {TRN['n']}명 · 운영/이전과정/안정화</div></div></div>
      <div class="card"><div class="sat"><div class="nm">MSA · 신규 개발</div><div class="score">{MSA['avg']}<small>/5</small></div>
        <div class="stars"><i style="width:{MSA['avg']*20}%"></i></div><div class="meta"><span class="{'lowN' if MSA['n']<10 else ''}">응답 {MSA['n']}명{' — 표본 소수, 해석 주의' if MSA['n']<10 else ''}</span></div></div></div>
      <div class="card"><div class="sat"><div class="nm">CMS · 홈페이지 전환</div><div class="score">{CMS['avg']}<small>/5</small></div>
        <div class="stars"><i style="width:{CMS['avg']*20}%"></i></div><div class="meta"><span class="{'lowN' if CMS['n']<10 else ''}">응답 {CMS['n']}명{' — 표본 소수, 참고치' if CMS['n']<10 else ''}</span></div></div></div>
    </div>
    <div class="note">※ 표본이 작은 영역(응답 10명 미만)의 점수는 ‘대상기관 담당자 한정 참고치’로 해석.</div>
  </section>

  <section>
    <div class="s-title"><span class="no">4</span><h2>통합 기대효과 · 우선순위</h2><span class="tag">다중선택 / 우선순위 ‘상’ 비율</span></div>
    <div class="grid g2">
      <div class="card"><h3>가장 기대되는 효과 (복수선택)</h3>{eff_rows()}</div>
      <div class="card"><h3>항목별 우선순위 ‘상’ 비율 <span class="n">n={D['N']}</span></h3>{prio_rows()}</div>
    </div>
    <div class="note">※ <b>‘{D['prio_sorted'][-1][0]}’이 우선순위 최하위</b> — 현장 기대가 낮은 항목으로, 해당 가치의 커뮤니케이션 보강 검토.</div>
  </section>

  <section>
    <div class="s-title"><span class="no">5</span><h2>현장 자유의견 (핵심 신호)</h2><span class="tag">작성 {D['free_written']}/{D['N']} · 유의미 의견 발췌</span></div>
    <div class="grid g2"><div class="quotes">{q1}</div><div class="quotes">{q2}</div></div>
    <div class="note">※ 형식적 응답 제외 후 발췌. 인프라 통합 이후의 운영·응용·거버넌스 관련 요구를 중점 확인.</div>
  </section>

  <section>
    <div class="s-title"><span class="no">6</span><h2>관점별 종합 진단</h2><span class="tag">사업관리 · 기술 · 비즈니스</span></div>
    <div class="grid g3">
      <div class="persp pm"><div class="ph"><span class="badge">사업관리</span> 추진 · 일정 · 참여</div><ul>
        <li>인지도 {D['know_proj_pct']:.0f}%, 전담관리 전환 인지 {D['know_tr_pct']:.1f}% — 준비도 양호</li>
        <li>전반 만족 {D['overall_avg']}, 불만 {D['dissat']}건 — 추진 성과 점검</li>
        <li>리스크: 응답 {D['N']}건 표본 규모 / 잔여 전환 점검</li></ul></div>
      <div class="persp tech"><div class="ph"><span class="badge">기술</span> 성능 · 안정화</div><ul>
        <li>TRN·MSA·CMS 전환 후 만족 {min(TRN['avg'],MSA['avg'],CMS['avg'])}~{max(TRN['avg'],MSA['avg'],CMS['avg'])}</li>
        <li>트래픽 집중 업무 무중단 운영 여부 확인</li>
        <li>과제: 응용 유지관리·ITSM·통합관제 성숙도</li></ul></div>
      <div class="persp biz"><div class="ph"><span class="badge">비즈니스</span> 가치 · 업무효과</div><ul>
        <li>최우선 기대: {te_label} ({te_pct:.1f}%) — 효율 기대 뚜렷</li>
        <li>{D['prio_sorted'][-1][0]} 체감 낮음 — 비전 공감 보강</li>
        <li>현업(비전산) 목소리 부족 — 효과 검증 한계</li></ul></div>
    </div>
  </section>

  <section>
    <div class="s-title"><span class="no">7</span><h2>결론 재점검 · 리스크 &amp; 빠진 부분</h2><span class="tag">수치 과잉해석 경계</span></div>
    <div class="card risk">
      <div class="ri"><div class="ic">!</div><div class="rt"><b>‘만족도’ 수치를 액면 그대로 읽지 말 것</b>
        <span>응답자 다수가 {D['job'][0][0]}({D['job'][0][2]:.1f}%) — 운영·추진에 가까운 집단의 자기평가 성격. 현업 일반 사용자 체감과 구분 필요.</span></div></div>
      <div class="ri"><div class="ic">N</div><div class="rt"><b>표본 작은 영역 일반화 금지</b>
        <span>응답 10명 미만 영역(MSA {MSA['n']}·CMS {CMS['n']} 등)은 ‘한정 참고치’로 명시.</span></div></div>
      <div class="ri"><div class="ic">▽</div><div class="rt"><b>{D['prio_sorted'][-1][0]} 공감 최저</b>
        <span>통합의 장기 명분이 체감되지 않는 항목. 활용 사례·비전 커뮤니케이션 보강 필요.</span></div></div>
      <div class="ri"><div class="ic">?</div><div class="rt"><b>빠진 데이터</b>
        <span>① 모집단 대비 응답률(분모) 미상 → {D['N']}건 대표성 판단 제한 ② 무응답·미참여층 잠재 불만 미파악 ③ 일자별 응답 추이(전일 대비) 자동 집계 권장.</span></div></div>
    </div>
  </section>

  <footer>경기도교육청 · 정보자원 통합 만족도 조사 일일 보고 · 데이터 기준 {D['agg_date']} 09:00 (응답 {D['N']}건)<br>
    만족도·표본 수치는 설문 원자료 기반 자동 집계이며, 소수 표본 항목은 참고치로 해석.</footer>
</div></body></html>"""

with open(os.path.join(OUT, "index.html"), "w", encoding="utf-8") as f:
    f.write(HTML)
print(f"[OK] 응답 {N}건 · 집계일 {agg_date} · index.html + report_data.json 생성 완료 → {OUT}")
