// 일일 보고 PPT 자동 생성 — report_data.json을 읽어 동일 형식으로 생성
// 사용법: node build_ppt.js [데이터JSON] [출력pptx]
const pptxgen = require("pptxgenjs");
const fs = require("fs");
const DATA = process.argv[2] || "report_data.json";
const OUTF = process.argv[3] || "report.pptx";
const D = JSON.parse(fs.readFileSync(DATA, "utf-8"));

const p = new pptxgen();
p.layout = "LAYOUT_WIDE";
p.author = "경기도교육청";
p.title = "정보자원 통합 만족도 조사 일일 보고";

const NAVY="13294B",NAVYDK="0C1C34",TEAL="0AA6A0",TEALDK="0A7D78",AMBER="E08A1E",
      INK="1C2733",MUTED="6B7686",LINE="D9E0EC",PAPER="F4F6FA",WHITE="FFFFFF",LIGHT="EEF1F6";
const HF="Calibri",HS="Cambria";
const sh=()=>({type:"outer",color:"000000",blur:7,offset:2,angle:90,opacity:0.10});
const f1=x=>(Math.round(x*10)/10);
const shorten=(t,n)=>t.length>n?t.slice(0,n-1)+"…":t;
function ddayTxt(){const d=D.dday; if(d==null)return "전환 잔여 점검"; if(d>0)return `전환 D-${d} 잔여 점검`; if(d===0)return "전환 D-Day(7/1) 점검"; return "전환 완료(7/1 경과) 점검";}

function eyebrow(s,t){s.addText(t,{x:0.7,y:0.5,w:11,h:0.3,fontFace:HF,fontSize:12,bold:true,color:NAVY,charSpacing:3});}
function pageTitle(s,t){s.addText(t,{x:0.7,y:0.78,w:11.9,h:0.7,fontFace:HS,fontSize:30,bold:true,color:NAVY,margin:0});}
function foot(s,n){
  s.addText(`경기도교육청 교육정보기록원  ·  정보자원 통합 만족도 일일 보고  ·  ${D.agg_date} 09:00 기준 (응답 ${D.N}건)`,
    {x:0.7,y:7.04,w:10.5,h:0.3,fontFace:HF,fontSize:9,color:MUTED,margin:0});
  s.addText(String(n),{x:12.4,y:7.0,w:0.5,h:0.35,fontFace:HF,fontSize:11,bold:true,color:MUTED,align:"right"});
}

/* ===== S1 TITLE ===== */
let s=p.addSlide(); s.background={color:NAVYDK};
s.addShape(p.shapes.OVAL,{x:9.4,y:-2.2,w:6,h:6,fill:{color:TEAL,transparency:78},line:{type:"none"}});
s.addShape(p.shapes.OVAL,{x:10.6,y:3.6,w:5,h:5,fill:{color:NAVY,transparency:40},line:{type:"none"}});
s.addText("경기도교육청",{x:0.9,y:1.35,w:10,h:0.4,fontFace:HF,fontSize:14,bold:true,color:"9FC7E8",charSpacing:3});
s.addText("정보자원 통합 성과 및\n시스템 이전·통합 만족도 조사",
  {x:0.9,y:1.95,w:11,h:1.7,fontFace:HS,fontSize:42,bold:true,color:WHITE,lineSpacing:46,margin:0});
s.addText(`설문 응답 현황 일일 리포트  ·  집계일 ${D.agg_date} 09:00  ·  응답기간 ${D.period}`,
  {x:0.92,y:3.75,w:11,h:0.4,fontFace:HF,fontSize:15,color:"C4D4E6",margin:0});
const k=[[`${D.N}건`,"누적 응답"],[`${Math.round(D.know_proj_pct)}%`,"사업 인지율"],
         [`${D.overall_avg}/5`,"전반 만족도"],[`${f1(D.top_effect[1])}%`,`${D.top_effect[0]} 최우선`]];
k.forEach((it,i)=>{const x=0.9+i*2.95;
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x,y:4.75,w:2.65,h:1.55,rectRadius:0.12,fill:{color:"FFFFFF",transparency:90},line:{color:"FFFFFF",transparency:75,width:1}});
  s.addText(it[0],{x,y:4.95,w:2.65,h:0.75,fontFace:HS,fontSize:32,bold:true,color:(i==3?AMBER:TEAL),align:"center",margin:0});
  s.addText(it[1],{x,y:5.72,w:2.65,h:0.4,fontFace:HF,fontSize:12.5,color:"C4D4E6",align:"center",margin:0});});

/* ===== S2 KPI ===== */
s=p.addSlide(); s.background={color:PAPER};
eyebrow(s,"01  핵심 지표 요약"); pageTitle(s,"추진 성과 요약 — 데이터 기반 점검");
const kpis=[[`${D.N}`,"건","누적 응답 수",TEALDK],
  [`${Math.round(D.know_proj_pct)}`,"%","통합 사업 인지율",NAVY],
  [`${D.overall_avg}`,"/5",`추진과정 전반 만족도 (n=${D.overall_n})`,TEALDK],
  [`${f1(D.know_tr_pct)}`,"%",`7/1 전담관리 전환 인지 (${D.know_tr_yes}/${D.know_tr_tot})`,NAVY]];
kpis.forEach((it,i)=>{const x=0.7+i*3.0;
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x,y:1.95,w:2.75,h:2.3,rectRadius:0.1,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
  s.addText([{text:it[0],options:{fontSize:50,bold:true,color:it[3],fontFace:HS}},{text:it[1],options:{fontSize:20,bold:true,color:MUTED,fontFace:HF}}],
    {x:x+0.05,y:2.25,w:2.65,h:1.0,align:"center",valign:"middle",margin:0});
  s.addText(it[2],{x:x+0.15,y:3.35,w:2.45,h:0.85,fontFace:HF,fontSize:12,color:MUTED,align:"center",valign:"top",margin:0});});
s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:0.7,y:4.7,w:11.95,h:1.55,rectRadius:0.08,fill:{color:"E8F6F5"},line:{color:"BfE5E2",width:1}});
s.addText([{text:"읽는 법  ",options:{bold:true,color:TEALDK,fontSize:15}},
  {text:`전반 만족도는 ‘통합 대상 시스템 관련자’ ${D.overall_n}명 응답 기준 (매우만족 ${D.very}·만족 ${D.satf}·불만족 ${D.dissat}). 응답자 다수가 운영·추진에 가까운 집단이라 `,options:{color:INK,fontSize:14}},
  {text:"‘자기평가’ 성격이 강한 점을 함께 볼 것.",options:{bold:true,color:AMBER,fontSize:14}}],
  {x:1.0,y:4.9,w:11.35,h:1.2,fontFace:HF,valign:"middle",lineSpacing:21,margin:0});
foot(s,2);

/* ===== S3 응답자 구성 ===== */
s=p.addSlide(); s.background={color:PAPER};
eyebrow(s,"02  응답자 구성"); pageTitle(s,`표본은 ‘${D.job[0][0].split("(")[0]}·실무 담당자’ 중심`);
s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:0.7,y:1.95,w:5.7,h:4.35,rectRadius:0.1,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
s.addText(`기관 유형  (n=${D.N})`,{x:1.0,y:2.2,w:5,h:0.4,fontFace:HF,fontSize:15,bold:true,color:NAVY,margin:0});
const instColors=[NAVY,TEAL,AMBER,MUTED];
s.addChart(p.charts.DOUGHNUT,[{name:"기관",labels:D.inst.map(x=>x[0]),values:D.inst.map(x=>x[1])}],
  {x:0.85,y:2.6,w:3.3,h:3.4,holeSize:62,chartColors:instColors.slice(0,D.inst.length),showLegend:false,showValue:false,dataBorder:{pt:2,color:WHITE}});
D.inst.slice(0,4).forEach((l,i)=>{const y=3.35+i*0.55;
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:4.3,y:y,w:0.22,h:0.22,rectRadius:0.04,fill:{color:instColors[i]},line:{type:"none"}});
  s.addText(shorten(l[0],6),{x:4.62,y:y-0.07,w:1.3,h:0.35,fontFace:HF,fontSize:12.5,color:INK,bold:true,margin:0,valign:"middle"});
  s.addText(`${l[1]} · ${Math.round(l[2])}%`,{x:4.6,y:y-0.07,w:1.7,h:0.35,fontFace:HF,fontSize:12,color:MUTED,align:"right",margin:0,valign:"middle"});});
s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:6.65,y:1.95,w:6,h:4.35,rectRadius:0.1,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
s.addText("직군 · 직급 분포",{x:6.95,y:2.2,w:5,h:0.4,fontFace:HF,fontSize:15,bold:true,color:NAVY,margin:0});
const mix=[...D.job.slice(0,2).map(x=>[shorten(x[0],8),x[2],x[1]+"명",TEAL]),
           ...D.rank.slice(0,2).map(x=>[shorten(x[0],8),x[2],x[1]+"명",NAVY])];
mix.forEach((b,i)=>{const y=2.78+i*0.70;
  s.addText(b[0],{x:6.95,y:y,w:1.6,h:0.35,fontFace:HF,fontSize:13,bold:true,color:INK,margin:0,valign:"middle"});
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:8.55,y:y+0.03,w:3.5,h:0.32,rectRadius:0.05,fill:{color:LIGHT},line:{type:"none"}});
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:8.55,y:y+0.03,w:Math.max(0.18,3.5*b[1]/100),h:0.32,rectRadius:0.05,fill:{color:b[3]},line:{type:"none"}});
  s.addText(b[2],{x:12.1,y:y,w:0.5,h:0.38,fontFace:HF,fontSize:12,bold:true,color:MUTED,align:"right",margin:0,valign:"middle"});});
s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:6.95,y:5.55,w:5.45,h:0.62,rectRadius:0.06,fill:{color:"FDF3E2"},line:{type:"none"}});
s.addText([{text:"표본 점검  ",options:{bold:true,color:AMBER,fontSize:12.5}},
  {text:"공급·운영 측 시각이 다수 — 현업 일반 사용자·관리자급 의견은 별도 확인 필요.",options:{color:INK,fontSize:12.5}}],
  {x:7.15,y:5.55,w:5.1,h:0.62,fontFace:HF,valign:"middle",margin:0});
foot(s,3);

/* ===== S4 전환 만족도 ===== */
s=p.addSlide(); s.background={color:PAPER};
eyebrow(s,"03  전환·통합 만족도"); pageTitle(s,"영역별 만족도 — 표본 규모 함께 확인");
const sat=[["TRN","이전 통합",D.TRN.avg,D.TRN.n],["MSA","신규 개발",D.MSA.avg,D.MSA.n],["CMS","홈페이지 전환",D.CMS.avg,D.CMS.n]];
sat.forEach((it,i)=>{const x=0.7+i*4.05; const low=it[3]<10;
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x,y:2.0,w:3.75,h:3.0,rectRadius:0.1,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
  s.addText(it[0],{x:x+0.35,y:2.25,w:3,h:0.45,fontFace:HS,fontSize:22,bold:true,color:NAVY,margin:0});
  s.addText(it[1],{x:x+0.35,y:2.72,w:3,h:0.3,fontFace:HF,fontSize:12.5,color:MUTED,margin:0});
  s.addText([{text:`${it[2].toFixed(2)}`,options:{fontSize:46,bold:true,color:TEALDK,fontFace:HS}},{text:" /5",options:{fontSize:18,bold:true,color:MUTED,fontFace:HF}}],
    {x:x+0.3,y:3.15,w:3.2,h:0.9,margin:0});
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:x+0.35,y:4.15,w:3.05,h:0.16,rectRadius:0.03,fill:{color:LIGHT},line:{type:"none"}});
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:x+0.35,y:4.15,w:3.05*it[2]/5,h:0.16,rectRadius:0.03,fill:{color:TEAL},line:{type:"none"}});
  s.addText([{text:`응답 ${it[3]}명  `,options:{bold:true,color:(low?AMBER:NAVY),fontSize:12}},
             {text:low?"· 표본 소수, 참고치":"· 다문항 평균",options:{color:MUTED,fontSize:11}}],
    {x:x+0.35,y:4.42,w:3.1,h:0.5,fontFace:HF,margin:0,valign:"top"});});
s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:0.7,y:5.4,w:12.05,h:0.85,rectRadius:0.07,fill:{color:"FDF3E2"},line:{type:"none"}});
s.addText([{text:"주의  ",options:{bold:true,color:AMBER,fontSize:14}},
  {text:"응답 10명 미만 영역은 대상기관 담당자만 응답한 ‘한정 참고치’ — 전체 사업 성과로 일반화하지 말 것.",options:{color:INK,fontSize:13.5}}],
  {x:1.0,y:5.4,w:11.5,h:0.85,fontFace:HF,valign:"middle",margin:0});
foot(s,4);

/* ===== S5 기대효과 ===== */
s=p.addSlide(); s.background={color:PAPER};
eyebrow(s,"04  통합 기대효과 · 우선순위"); pageTitle(s,`기대 쏠림 점검 — ${D.prio_sorted[D.prio_sorted.length-1][0]}은 최하위`);
s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:0.7,y:1.95,w:5.95,h:4.35,rectRadius:0.1,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
s.addText("가장 기대되는 효과 (복수선택)",{x:1.0,y:2.2,w:5.5,h:0.4,fontFace:HF,fontSize:14.5,bold:true,color:NAVY,margin:0});
const effAsc=[...D.eff_sorted].reverse();
const effMax=Math.max(...D.eff_sorted.map(x=>x[2]),1);
s.addChart(p.charts.BAR,[{name:"선택수",labels:effAsc.map(x=>x[0]),values:effAsc.map(x=>x[2])}],
  {x:0.85,y:2.65,w:5.7,h:3.5,barDir:"bar",chartColors:[TEAL],showValue:true,dataLabelPosition:"outEnd",
   dataLabelColor:INK,dataLabelFontSize:11,dataLabelFontBold:true,catAxisLabelColor:INK,catAxisLabelFontSize:11,
   valAxisHidden:true,valGridLine:{style:"none"},catGridLine:{style:"none"},showLegend:false,barGapWidthPct:45,valAxisMaxVal:Math.ceil(effMax*1.15)});
s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:6.85,y:1.95,w:5.8,h:4.35,rectRadius:0.1,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
s.addText(`항목별 우선순위 ‘상’ 비율 (n=${D.N})`,{x:7.15,y:2.2,w:5.5,h:0.4,fontFace:HF,fontSize:14.5,bold:true,color:NAVY,margin:0});
const lowestP=Math.min(...D.prio_sorted.map(x=>x[2]));
D.prio_sorted.forEach((b,i)=>{const y=2.68+i*0.50; const col=(b[2]===lowestP)?AMBER:NAVY;
  s.addText(b[0],{x:7.15,y:y,w:1.9,h:0.35,fontFace:HF,fontSize:12,bold:true,color:INK,margin:0,valign:"middle"});
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:9.1,y:y+0.02,w:2.85,h:0.3,rectRadius:0.05,fill:{color:LIGHT},line:{type:"none"}});
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:9.1,y:y+0.02,w:Math.max(0.1,2.85*b[2]/100),h:0.3,rectRadius:0.05,fill:{color:col},line:{type:"none"}});
  s.addText(f1(b[2])+"%",{x:11.98,y:y,w:0.65,h:0.34,fontFace:HF,fontSize:11.5,bold:true,color:MUTED,align:"right",margin:0,valign:"middle"});});
s.addText([{text:"시사점  ",options:{bold:true,color:AMBER,fontSize:12}},
  {text:`현장 기대는 상위 항목에 쏠림. 최하위 ‘${D.prio_sorted[D.prio_sorted.length-1][0]}’ 가치는 커뮤니케이션 보강 검토.`,options:{color:INK,fontSize:11.5}}],
  {x:7.15,y:5.72,w:5.3,h:0.5,fontFace:HF,margin:0,valign:"top"});
foot(s,5);

/* ===== S6 자유의견 ===== */
s=p.addSlide(); s.background={color:PAPER};
eyebrow(s,"05  현장 자유의견 (핵심 신호)"); pageTitle(s,"인프라 다음 과제 — 운영·응용·거버넌스");
const qs=D.free.slice(0,4);
const dotc=[AMBER,AMBER,NAVY,NAVY];
if(qs.length===0){ s.addText("유의미한 자유의견 없음",{x:0.7,y:3,w:12,h:1,fontFace:HF,fontSize:16,color:MUTED,align:"center"}); }
qs.forEach((q,i)=>{const col=i%2,row=Math.floor(i/2);const x=0.7+col*6.05,y=2.0+row*1.72;
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x,y,w:5.85,h:1.5,rectRadius:0.09,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
  s.addShape(p.shapes.OVAL,{x:x+0.28,y:y+0.6,w:0.3,h:0.3,fill:{color:dotc[i]},line:{type:"none"}});
  s.addText(`“${shorten(q,46)}”`,{x:x+0.72,y:y+0.22,w:4.95,h:1.1,fontFace:HF,fontSize:13.5,color:"28323F",margin:0,valign:"middle",lineSpacing:18});});
s.addText([{text:`작성 ${D.free_written}/${D.N}명  `,options:{bold:true,color:NAVY,fontSize:12}},
  {text:"· 형식적 응답 제외 후 발췌. 방향은 운영 성숙도(ITSM)·응용 통합·거버넌스로 수렴.",options:{color:MUTED,fontSize:12}}],
  {x:0.7,y:5.55,w:12,h:0.5,fontFace:HF,margin:0});
foot(s,6);

/* ===== S7 관점별 ===== */
s=p.addSlide(); s.background={color:PAPER};
eyebrow(s,"06  관점별 종합 진단"); pageTitle(s,"사업관리 · 기술 · 비즈니스");
const lo=D.prio_sorted[D.prio_sorted.length-1][0];
const sats=[D.TRN.avg,D.MSA.avg,D.CMS.avg];
const persp=[
  ["사업관리","추진·일정·참여",NAVY,
   [`인지도 ${Math.round(D.know_proj_pct)}%, 7/1 전환 인지 ${f1(D.know_tr_pct)}% — 전환 직전 준비도 양호`,
    `전반 만족 ${D.overall_avg}, 불만 ${D.dissat}건 — 추진 성과 자체는 긍정`,
    `리스크: 응답 ${D.N}건으로 표본 작음 / 미참여층 응답 확보 점검`]],
  ["기술","성능·안정화",TEALDK,
   [`TRN·MSA·CMS 전환 후 만족 ${f1(Math.min(...sats))}~${f1(Math.max(...sats))} — 안정화 성공적`,
    "예약 등 트래픽 집중 업무 무중단 운영 확인(MSA)",
    "과제: 응용 유지관리·ITSM·통합관제 등 운영 성숙도"]],
  ["비즈니스","가치·업무효과",AMBER,
   ["보안·예산·업무경감 기대 高 → 운영 효율 기대 뚜렷",
    `${lo} 가치 체감 低 → 미래 비전 공감 부족`,
    "현업(비전산) 사용자 목소리 부족 → 효과 검증 한계"]],
];
persp.forEach((c,i)=>{const x=0.7+i*4.05;
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x,y:1.95,w:3.75,h:4.5,rectRadius:0.1,fill:{color:WHITE},line:{color:LINE,width:1},shadow:sh()});
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x:x+0.3,y:2.25,w:1.85,h:0.5,rectRadius:0.25,fill:{color:c[2]},line:{type:"none"}});
  s.addText(c[0],{x:x+0.3,y:2.25,w:1.85,h:0.5,fontFace:HF,fontSize:14,bold:true,color:WHITE,align:"center",valign:"middle",margin:0});
  s.addText(c[1],{x:x+0.3,y:2.85,w:3.2,h:0.35,fontFace:HF,fontSize:12.5,color:MUTED,margin:0});
  s.addText(c[3].map(t=>({text:t,options:{bullet:{indent:14},breakLine:true,paraSpaceAfter:9,color:INK,fontSize:12.5}})),
    {x:x+0.32,y:3.35,w:3.25,h:2.9,fontFace:HF,valign:"top",lineSpacing:16,margin:0});});
foot(s,7);

/* ===== S8 리스크 ===== */
s=p.addSlide(); s.background={color:NAVYDK};
s.addShape(p.shapes.OVAL,{x:-2,y:4.5,w:6,h:6,fill:{color:TEAL,transparency:82},line:{type:"none"}});
s.addText("07  결론 재점검 · 리스크 & 빠진 부분",{x:0.9,y:0.55,w:11,h:0.4,fontFace:HF,fontSize:13,bold:true,color:"9FC7E8",charSpacing:3});
s.addText("수치는 좋다 — 그러나 ‘누가 답했나·무엇이 빠졌나’를 함께 보고",
  {x:0.9,y:1.0,w:11.5,h:0.7,fontFace:HS,fontSize:27,bold:true,color:WHITE,margin:0});
const risks=[
  ["①","‘만족도’ 수치를 액면대로 읽지 말 것",`응답자 다수가 ${D.job[0][0].split("(")[0]}(${f1(D.job[0][2])}%) — 운영 주체의 자기평가 성격. 긍정 편향 가능.`],
  ["②","표본 작은 영역 일반화 금지",`응답 10명 미만(MSA ${D.MSA.n}·CMS ${D.CMS.n} 등)은 ‘한정 참고치’로 명시.`],
  ["③",`${lo} 가치, 현장 공감 최저`,"통합의 장기 명분(데이터 연계 행정)이 체감 안 됨. 전환 후 비전·활용 사례 커뮤니케이션 보강 필요."],
  ["④","다음 과제는 ‘인프라’가 아니라 ‘운영·응용·거버넌스’","자유의견이 ITSM·응용 통합·전담 조율조직·협력강화로 수렴. 7/1 전담관리 개시 후 운영 SLA·협업체계가 실제 만족 좌우."],
  ["⑤","빠진 데이터 (분모·미참여층·추이)",`모집단 대비 응답률 미상 → ${D.N}건 대표성 판단 제한. 무응답층 잠재 불만·일자별 추이 추가 집계 권장.`],
];
risks.forEach((r,i)=>{const y=2.0+i*0.93;
  s.addShape(p.shapes.OVAL,{x:0.9,y:y,w:0.5,h:0.5,fill:{color:TEAL},line:{type:"none"}});
  s.addText(r[0],{x:0.9,y:y,w:0.5,h:0.5,fontFace:HF,fontSize:17,bold:true,color:WHITE,align:"center",valign:"middle",margin:0});
  s.addText([{text:r[1]+"   ",options:{bold:true,color:WHITE,fontSize:15}},{text:r[2],options:{color:"C4D4E6",fontSize:12.5}}],
    {x:1.6,y:y-0.04,w:11,h:0.8,fontFace:HF,valign:"middle",lineSpacing:16,margin:0});});
s.addText(`경기도교육청 교육정보기록원 · 정보자원 통합 만족도 일일 보고 · ${D.agg_date} 09:00 기준`,
  {x:0.9,y:7.05,w:11,h:0.3,fontFace:HF,fontSize:9,color:"7E93AD",margin:0});

p.writeFile({fileName:OUTF}).then(f=>console.log("[OK] PPT 생성:",f));
